
<?php

$products['A1'] = array('name' => 'banana' , 'price' => 1,"qty"=>8,"picture"=>'banana.jpg');
$products['A2'] = array('name' => 'apple' , 'price' => 2,"qty"=>5,"picture"=>'apple.jpg');
$products['A3'] = array('name' => 'mango' , 'price' => 4,"qty"=>10,"picture"=>'mango.jpg');
$products['A4'] = array('name' => 'orange' , 'price' => 3,"qty"=>11,"picture"=>'orange.jpg');


?>
<img src="images/banana.jpg" alt="Fruit 1">
        <h2>Banana</h2>
        <p>Description of Fruit 1</p>
        <p class="price">$2.99</p>
        <div class="quantity">
        <input type="number" value="1" min="1">
        <button>Add to Cart</button>
        </div>
    </div>

    <div class="product">
        <img src="images/apple.jpg" alt="Fruit 2">
        <h2>Apple</h2>
        <p>Description of Fruit 2</p>
        <p class="price">$1.99</p>
        <div class="quantity">
        <input type="number" value="1" min="1">
        <button>Add to Cart</button>
        </div>
    </div>

    <div class="product">
        <img src="images/orange.jpg" alt="Fruit 3">
        <h2>Orange</h2>
        <p>Description of Fruit 2</p>
        <p class="price">$9.99</p>
        <div class="quantity">
        <input type="number" value="1" min="1">
        <button>Add to Cart</button>
        </div>
    </div>

    <div class="product">
        <img src="images/mango.jpg" alt="Fruit 4">
        <h2>Mango</h2>
        <p>Description of Fruit 2</p>
        <p class="price">$11.99</p>
        <div class="quantity">
        <input type="number" value="1" min="1">
        <button>Add to Cart</button>
        </div>
    </div>

  <!-- Add more product divs as needed -->
</div>  