<?php
try {
    require('connection.php');
    $sql = "SELECT o.Order_id, o.Username, o.Status, 
                   p.Name AS product_name, oi.quantity, (p.Price * oi.quantity) AS item_total_price
            FROM orders AS o 
            JOIN order_items AS oi ON o.Order_id = oi.orderid 
            JOIN products AS p ON oi.pid = p.Pid 
            WHERE o.Username = 'Yousef12' AND o.Status != 'Completed'
            ORDER BY o.Order_id";
    $pd = $db->prepare($sql);
    $pd->execute();
} catch (PDOException $e) {
    die($e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermarket</title>
    <link rel="stylesheet" href="st.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <header>
        <div class="detail">
            <h1>Welcome to Our Supermarket</h1>
            <form method="post" action="search.php" class="search-form">
                <input id="se" type="text" value="Search for an Item" name="search">
                <button type="submit" name="sb"><i class="fas fa-search"></i></button>
            </form>
            <nav>
                <a href="mainpage.php"><i class="fas fa-home"></i> Home</a>
                <a href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
                <a href="#">Contact</a>
            </nav>
        </div>
    </header>

    <section class="fruit"></section>
    <main>
        <div class="category-products">
            <table border="1">
                <tr>
                    <th>Order Id</th>
                    <th>Username</th>
                    <th>Status</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Item Total Price</th>
                    <th>Total Price (with delivery)</th>
                </tr>
                <?php
                $currentOrderId = null;
                $totalPrice = 0;
                $rowspan = 0;
                $orderCount = 0;

                while ($details = $pd->fetch(PDO::FETCH_ASSOC)) {
                    if ($details['Order_id'] !== $currentOrderId) {
                        if ($currentOrderId !== null) {
                            $totalPriceWithDelivery = $totalPrice + 0.7;
                            echo "<tr>";
                            echo "<td colspan='6' style='text-align:right;'>Total Price (with delivery):</td>";
                            echo "<td>" . htmlspecialchars(number_format($totalPriceWithDelivery, 2)) . "</td>";
                            echo "</tr>";
                        }
                        $currentOrderId = $details['Order_id'];
                        $totalPrice = 0;
                        $rowspan = $db->query("SELECT COUNT(*) FROM order_items WHERE orderid = " . $details['Order_id'])->fetchColumn();
                        echo "<tr>";
                        echo "<td rowspan='$rowspan'>" . htmlspecialchars($details['Order_id']) . "</td>";
                        echo "<td rowspan='$rowspan'>" . htmlspecialchars($details['Username']) . "</td>";
                        echo "<td rowspan='$rowspan'>" . htmlspecialchars($details['Status']) . "</td>";
                    } else {
                        echo "<tr>";
                    }
                    $totalPrice += $details['item_total_price'];
                    ?>
                    <td><?php echo htmlspecialchars($details['product_name']); ?></td>
                    <td><?php echo htmlspecialchars($details['quantity']); ?></td>
                    <td><?php echo htmlspecialchars(number_format($details['item_total_price'], 2)); ?></td>
                    <?php
                    if ($details['Order_id'] === $currentOrderId) {
                        echo "</tr>";
                    }
                }
                if ($currentOrderId !== null) {
                    $totalPriceWithDelivery = $totalPrice + 0.7;
                    echo "<tr>";
                    echo "<td colspan='6' style='text-align:right;'>Total Price (with delivery):</td>";
                    echo "<td>" . htmlspecialchars(number_format($totalPriceWithDelivery, 2)) . "</td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>
    </main>
</body>
</html>
