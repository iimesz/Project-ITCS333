<?php
try{
    require('connection.php');
    $sql = "SELECT o.* , oi.orderid,oi.pid,oi.quantity FROM orders AS o 
    JOIN order_items AS oi 
    ON o.Order_id=oi.orderid Where o.Username = 'Yousef12' AND o.Status != 'Completed'";
    $pd= $db->prepare($sql);
    $pd->execute();
}
catch(PDOException $e){
    die($e->getMessage());
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermarket</title>
    <link rel="stylesheet" href="st.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <header>
        <div class="detail">
            <h1>Welcome to Our Supermarket</h1>
            <form method="post" action="search.php" class="search-form">
                <input id="se" type="text" value="Search for an Item" name="search">
                <button type="submit" name="sb"><i class="fas fa-search"></i></button>
            </form>
            <nav>
                <a href="mainpage.php"><i class="fas fa-home"></i> Home</a>
                <a href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
                <a href="#">Contact</a>
            </nav>
        </div>
    </header>

    <section class="fruit"></section>
    <main>
        <div class="category-products">
            <?php
            if($details=$pd->fetch(PDO::FETCH_ASSOC)){
                extract($details);
                try{
                    $sql2= "select Price from products where Pid=$pid";
                    $data= $db->query($sql2);
                    $product = $data->fetch(PDO::FETCH_ASSOC);
                    extract($product);
                }
                catch(PDOException $e){
                    die($e->getMessage());
                }
                echo "<div class='product'>";
                echo "<table border=1>";
                echo "<tr>";
                echo "<th>Order Id</th>";
                echo "<th>Username</th>";
                echo "<th>Status</th>";
                echo "</tr>";
                echo "<tr>";
                echo "<td>$Order_id</td>";
                echo "<td>$Username</td>";
                echo "<td>$Status</td>";
                echo "<tr>";
                echo "</table>";
                echo "</div>";
            }
            
            ?>
        </div>
    </main>
</body>
</html>
