
<?php
$data['User1']= array('name'=>'Ali123' , 'password' => '300' ,'type'=>'staff');
$data['User2']= array('name'=>'Ali123' , 'password' => '300');

$products['A1'] = array('name' => 'banana' , 'price' => 1,"qty"=>8,"picture"=>'banana.jpeg');
$products['A2'] = array('name' => 'apple' , 'price' => 2,"qty"=>5,"picture"=>'apple.jpeg');
$products['A3'] = array('name' => 'mango' , 'price' => 4,"qty"=>10,"picture"=>'mango.jpeg');
$products['A4'] = array('name' => 'orange' , 'price' => 3,"qty"=>11,"picture"=>'orange.jpeg');


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="project.html" method="post">
        Usernmae:
        <input type="text" name = 'un'/>
        Password:
        <input type="password" name='ps'/>
    </form>
</body>
</html>