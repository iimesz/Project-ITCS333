<?php
try {
    require('connection.php');
    $sql = "SELECT o.*, oi.orderid, oi.pid, oi.quantity, p.Picture, p.Price
            FROM orders AS o
            JOIN order_items AS oi ON o.Order_id = oi.orderid
            JOIN products AS p ON oi.pid = p.Pid
            WHERE o.Username = 'Yousef12' AND o.Status = 'Completed'
            ORDER BY o.Date";
    $pd = $db->prepare($sql);
    $pd->execute();
} catch (PDOException $e) {
    die($e->getMessage());
}

$orders = [];
while ($details = $pd->fetch(PDO::FETCH_ASSOC)) {
    $orders[$details['Date']][] = $details;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermarket</title>
    <link rel="stylesheet" href="ttttr.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <header>
        <div class="detail">
            <h1>Welcome to Our Supermarket</h1>
            <form method="post" action="search.php" class="search-form">
                <input id="se" type="text" value="Search for an Item" name="search">
                <button type="submit" name="sb"><i class="fas fa-search"></i></button>
            </form>
            <nav>
                <a href="mainpage.php"><i class="fas fa-home"></i> Home</a>
                <a href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
                <a href="#">Contact</a>
            </nav>
        </div>
    </header>

    <section class="fruit"></section>
    <main>
        <div class="category-products">
            <?php
            foreach ($orders as $date => $orderDetails) {
                echo "<h2 style='text-align:center'>Orders on $date</h2>";
                foreach ($orderDetails as $details) {
                    echo "<div class='product'>";
                    echo "<img src='images/" . $details['Picture'] . "' alt='Product Image'>";
                    echo "<h3>" . $details['Username'] . "</h3>";
                    echo "<p>Price: " . $details['Price'] . " BD</p>";
                    echo "<p>Quantity: " . $details['quantity'] . "</p>";
                    echo "</div>";
                }
            }
            ?>
        </div>
    </main>
</body>
</html>
