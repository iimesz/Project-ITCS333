<?php
try{
    require('connection.php');
    $sql = "SELECT o.* , oi.orderid,oi.pid,oi.quantity FROM orders AS o 
    JOIN order_items AS oi 
    ON o.Order_id=oi.orderid Where o.Username = 'Yousef12' AND o.Status='Completed'";
    $pd= $db->prepare($sql);
    $pd->execute();
}
catch(PDOException $e){
    die($e->getMessage());
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supermarket</title>
    <link rel="stylesheet" href="ttttr.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <header>
        <div class="detail">
            <h1>Welcome to Our Supermarket</h1>
            <form method='post' action='search.php' class="search-form">
                <input id='se' type="text" value='Search for an Item' name="search">
                <button type="submit" name='sb'><i class="fas fa-search"></i></button>
            </form>
            <nav>
                <a href='mainpage.php'><i class="fas fa-home"></i> Home</a>
                <a href="cart.php"><i class="fas fa-shopping-cart"></i>Cart</a>
                <a href="#">Contact</a>
            </nav>
        </div>
    </header>

<section class="fruit"></section>
<main>
  <div class="category-products">
        <?php
        while($details=$pd->fetch(PDO::FETCH_ASSOC)){
            extract($details);
            try{
                $sql2= "select * from products where Pid=$pid";
                $data= $db->query($sql2);
                $product = $data->fetch(PDO::FETCH_ASSOC);
            }
            catch(PDOException $e){
                die($e->getMessage());
            }
            echo "<div class='product'>";
            echo"<img src='images/".$product['Picture']."'alt='Fruit 1'>";
            echo "<h3>$Username</h3></br>";
            echo "<p>Price:".$product['Price']."BD</p></br>";
            echo "<p>$quantity</p>";
            echo "</div>";
        }
        ?>
    </div>
</main>

